
package net.mcreator.robocraft.client.renderer;

import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.cache.object.BakedGeoModel;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.mcreator.robocraft.entity.model.FlyingRobotModel;
import net.mcreator.robocraft.entity.FlyingRobotEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class FlyingRobotRenderer extends GeoEntityRenderer<FlyingRobotEntity> {
	public FlyingRobotRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new FlyingRobotModel());
		this.shadowRadius = 0.5f;
	}

	@Override
	public RenderType getRenderType(FlyingRobotEntity animatable, ResourceLocation texture, MultiBufferSource bufferSource, float partialTick) {
		return RenderType.entityTranslucent(getTextureLocation(animatable));
	}

	@Override
	public void preRender(PoseStack poseStack, FlyingRobotEntity entity, BakedGeoModel model, MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, int color) {
		float scale = 1f;
		this.scaleHeight = scale;
		this.scaleWidth = scale;
		super.preRender(poseStack, entity, model, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, color);
	}

	@Override
	protected float getDeathMaxRotation(FlyingRobotEntity entityLivingBaseIn) {
		return 0.0F;
	}
}
